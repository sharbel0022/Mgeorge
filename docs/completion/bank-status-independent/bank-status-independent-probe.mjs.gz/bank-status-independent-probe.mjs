import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { createHash, generateKeyPairSync } from 'node:crypto';
import ts from 'typescript';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { emptyState } from '../lib/domain.ts';
import { bankUtcDate } from '../lib/banking/sync-periods.ts';
import { ProviderError } from '../lib/banking/enable-banking.ts';
import { ConsentError, bankAccountScopeError, validateLegacyEnableSelection } from '../lib/bank-consent-policy.js';
import { seal, unseal, randomToken, digest, validFlowToken, cookieValue } from '../lib/banking/security.ts';
import { runtimeBankConfig, runtimeBankStatus } from '../lib/banking/runtime-config.ts';
import { confirmedBankConsent } from '../lib/banking/status-view.ts';
import { accountReadCooldown } from '../lib/banking/account-read-cooldown.ts';
import { applyCurrentMigrations, businessSql } from './helpers/company-compat-fixture.mjs';
import { provisionCompany } from '../lib/company-storage.js';

// Exercise the real route services, encryption, domain and SQL. Only the identity
// provider and banking HTTP boundary are replaced. No test can call a live bank.
const source = path => readFileSync(path === '../lib/banking/service.ts' ? process.env.STATUS_REVIEW_SERVICE_PATH : new URL(path, import.meta.url), 'utf8');
// Short file URLs keep dependent source out of each ESM cache key. Content
// addressing preserves the old loader's identity for identical module text.
const moduleDirectory = mkdtempSync(join(tmpdir(), 'mg-bank-security-'));
after(() => rmSync(moduleDirectory, { recursive: true, force: true }));
const jsUrl = value => {
  const bytes = Buffer.from(value);
  const file = join(moduleDirectory, createHash('sha256').update(bytes).digest('hex') + '.mjs');
  if (existsSync(file)) {
    if (!readFileSync(file).equals(bytes)) throw new Error('Synthetic module hash collision');
  } else writeFileSync(file, bytes, { mode: 0o600, flag: 'wx' });
  return pathToFileURL(file).href;
};
function compiledModule(path, imports, jsx = ts.JsxEmit.Preserve) {
  imports = { '../bank-consent-policy.js': new URL('../lib/bank-consent-policy.js', import.meta.url).href, '../bank-company-authority.js': new URL('../lib/bank-company-authority.js', import.meta.url).href, './account-read-cooldown': new URL('../lib/banking/account-read-cooldown.ts', import.meta.url).href, './sync-periods': new URL('../lib/banking/sync-periods.ts', import.meta.url).href, '../payer-evidence.js': new URL('../lib/payer-evidence.js', import.meta.url).href, ...imports };
  let js = ts.transpileModule(source(path), { fileName: path, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, jsx } }).outputText;
  for (const [name, replacement] of Object.entries(imports)) {
    for (const quote of ['"', "'"]) js = js.replaceAll(`${quote}${name}${quote}`, JSON.stringify(replacement));
  }
  return jsUrl(js);
}

class LocalD1 {
  constructor(sqlite) { this.sqlite = sqlite; this.beforeBatch = null; }
  prepare(sql) {
    const database = this;
    return {
      sql, values: [],
      bind(...values) { this.values = values; return this; },
      async first() { return database.sqlite.prepare(sql).get(...this.values) ?? null; },
      async all() { return { results: database.sqlite.prepare(sql).all(...this.values), success: true }; },
      async run() { return this.execute(); },
      execute() { const result = database.sqlite.prepare(sql).run(...this.values); return { success: true, meta: { changes: Number(result.changes) } }; },
    };
  }
  async batch(statements) {
    if (this.beforeBatch) await this.beforeBatch(statements);
    this.sqlite.exec('BEGIN');
    try {
      const results = statements.map(statement => statement.execute());
      this.sqlite.exec('COMMIT');
      return results;
    } catch (error) { this.sqlite.exec('ROLLBACK'); throw error; }
  }
}

const appId = '11111111-1111-4111-8111-111111111111';
const accountUid = '22222222-2222-4222-8222-222222222222';
const remoteSession = '33333333-3333-4333-8333-333333333333';
const origin = 'https://mg-fakturakoll-sharbel.asdasdsa213.chatgpt.site';
const redirect = `${origin}/api/bank/callback`;
const cookieName = '__Secure-mg-bank-flow';
const future = () => new Date(Date.now() + 86400_000).toISOString();
const rawTx = (patch = {}) => ({ entry_reference: 'BANK-001', transaction_amount: { amount: '1875.00', currency: 'SEK' }, credit_debit_indicator: 'CRDT', status: 'BOOK', booking_date: bankUtcDate(), debtor: { name: 'Example customer' }, reference_number: '10019', remittance_information: ['Invoice 1001'], ...patch });
const post = (path, body = {}, requestOrigin = origin, servedOrigin = origin) => new Request(`${servedOrigin}/api/bank/${path}`, {
  method: 'POST', headers: { 'Content-Type': 'application/json', ...(requestOrigin === null ? {} : { Origin: requestOrigin }), 'CF-Connecting-IP': '192.0.2.1', 'User-Agent': 'MG local security tests' }, body: JSON.stringify(body),
});
const count = (f, table) => f.sql.prepare(`SELECT count(*) AS n FROM ${table}`).get().n;
const financialAuditCount = f => f.sql.prepare("SELECT count(*) AS n FROM audit_events WHERE action NOT LIKE 'bank.job.%'").get().n;
const bankJobEvents = f => f.sql.prepare("SELECT action,detail,created_at,revision FROM audit_events WHERE owner=? AND action LIKE 'bank.job.%' ORDER BY rowid").all(f.owner).map(row=>({...row,detail:JSON.parse(row.detail)}));
const usageCounts = (patch={}) => ({omitted:0,orga:0,priv:0,explicitNull:0,otherString:0,wrongType:0,...patch});
const usageDiagnostic = (saved,live,selectedCount=1) => ({version:'selected-account-usage-v1',selectedCount,saved:usageCounts(saved),live:usageCounts(live)});

async function fixture(t, environment = 'PRODUCTION', { actualProvider = false, companyContext = false } = {}) {
  const key = `__mgBankTest_${crypto.randomUUID().replaceAll('-', '')}`;
  const sql = new DatabaseSync(':memory:');
  applyCurrentMigrations(sql);
  const f = { sql, owner: 'owner-alice', user: { userId: 'owner-alice' }, calls: [], provider: {}, env: {
    BANK_DATA_ENCRYPTION_KEY: randomToken(), ENABLE_BANKING_APPLICATION_ID: appId,
    ENABLE_BANKING_PRIVATE_KEY: '-----BEGIN PRIVATE KEY-----\nVEVTVC1PTkxZLU5PVC1SRUFM\n-----END PRIVATE KEY-----',
    ENABLE_BANKING_ENVIRONMENT: environment, ENABLE_BANKING_KEY_ROTATED: 'true', ENABLE_BANKING_REDIRECT_URL: redirect,
  } };
  f.d1 = new LocalD1(sql); f.env.DB = f.d1;
  globalThis[key] = f;
  t.after(() => { delete globalThis[key]; sql.close(); });
  t.mock.method(globalThis, 'fetch', async () => { throw new Error('Live network access is forbidden in security tests'); });
  const cloudflare = jsUrl(`export const env=globalThis[${JSON.stringify(key)}].env;`);
  const auth = jsUrl(`export async function getChatGPTUser(){return globalThis[${JSON.stringify(key)}].user;}`);
  const domain = new URL('../lib/domain.ts', import.meta.url).href;
  const security = new URL('../lib/banking/security.ts', import.meta.url).href;
  const serverUrl = compiledModule('../lib/server.ts', {'./company-storage.js':new URL('../lib/company-storage.js',import.meta.url).href, 'cloudflare:workers': cloudflare, '@/app/chatgpt-auth': auth, './domain': domain });
  const runtimeConfig = new URL('../lib/banking/runtime-config.ts', import.meta.url).href;
  const normalizerUrl = compiledModule('../lib/banking/transactions.ts', { '../domain': domain, '../payment-references.js': new URL('../lib/payment-references.js', import.meta.url).href });
  const storeServerUrl = companyContext ? jsUrl(`export * from ${JSON.stringify(serverUrl)}; export function currentCompanyContext(){return globalThis[${JSON.stringify(key)}].companyContext??null;}`) : serverUrl;
  const storeUrl = compiledModule('../lib/banking/store.ts', { 'cloudflare:workers': cloudflare, '@/lib/server': storeServerUrl, './security': security, './runtime-config': runtimeConfig, './transactions': normalizerUrl });
  const providerFunctions = ['getApplication', 'listBusinessBanks', 'startAuth', 'createSession', 'getSession', 'getAccountDetails', 'deleteSession', 'getTransactions'];
  const providerUrl = actualProvider ? new URL('../lib/banking/enable-banking.ts', import.meta.url).href : jsUrl(`export {ProviderError,providerCooldownDiagnostic,providerErrorCode,providerResponseDiagnostic} from ${JSON.stringify(new URL('../lib/banking/enable-banking.ts', import.meta.url).href)};` + providerFunctions.map(name => `export async function ${name}(...args){const f=globalThis[${JSON.stringify(key)}];f.calls.push({name:${JSON.stringify(name)},args});return f.provider[${JSON.stringify(name)}](...args);}`).join('\n'));
  const readGuardUrl = compiledModule('../lib/banking/account-read-guard.ts', { '../server': serverUrl, './store': storeUrl, './enable-banking': providerUrl });
  const openPaymentsSchedulerUrl = compiledModule('../lib/banking/openpayments-scheduler.ts', { 'cloudflare:workers': cloudflare, '../server': serverUrl });
  const serviceUrl = compiledModule('../lib/banking/service.ts', { '@/lib/server': serverUrl, '@/lib/domain': domain, './enable-banking': providerUrl, './transactions': normalizerUrl, './store': storeUrl, './security': security, './runtime-config': runtimeConfig, './account-read-guard': readGuardUrl, './openpayments-scheduler':openPaymentsSchedulerUrl, './company-sync':jsUrl('export async function dispatchCompanyAutomaticSync(){return null;}'), '../bankgiro-ingest-service':jsUrl(`export async function runBankgiroSource(owner){globalThis[${JSON.stringify(key)}].reportOwner=owner;return {enabled:false,state:'DISABLED'};}`),'../customer-messages': jsUrl(`export async function reconcileAndPrepare(){if(globalThis[${JSON.stringify(key)}].reconcileError)throw Error('synthetic postprocessing failure');}`) });
  f.server = await import(serverUrl); f.store = await import(storeUrl); f.service = await import(serviceUrl);
  f.mcp = await import(compiledModule('../lib/banking/mcp.ts', { './service': serviceUrl }));
  f.info = { name: 'Local test app', kid: appId, environment, active: true, redirect_urls: [redirect], countries: ['SE'], services: ['AIS'] };
  f.account = { uid: accountUid, name: 'Company account', currency: 'SEK', account_id: { iban: 'SE4550000000058398257466' } };
  f.bank = { name: 'Swedbank', country: 'SE', psu_types: ['business'], maximum_consent_validity: 15552000 };
  f.live = { status: 'AUTHORIZED', accounts: [accountUid], accounts_data: [{ uid: accountUid }], aspsp: { name: 'Swedbank', country: 'SE' }, psu_type: 'business', access: { valid_until: future() }, created: new Date().toISOString() };
  f.provider = {
    getApplication: async () => structuredClone(f.info),
    listBusinessBanks: async () => [structuredClone(f.bank)],
    startAuth: async (_config, options) => { f.auth = options; return { url: 'https://auth.enablebanking.com/ais/start?test=1' }; },
    createSession: async () => ({ session_id: remoteSession, accounts: [structuredClone(f.account)], aspsp: { name: 'Swedbank', country: 'SE' }, psu_type: 'business', access: { valid_until: future() } }),
    getSession: async () => structuredClone(f.live),
    deleteSession: async () => {},
    getTransactions: async () => ({ transactions: [rawTx()] }),
  };
  f.seedApp = async (owner = f.owner) => {
    const current = await f.store.application(owner);
    const encrypted = await f.store.encrypt(owner, 'key:generation-one', 'PRIVATE-TEST-KEY');
    sql.prepare('INSERT INTO bank_applications VALUES (?,?,?,?,?,?,?)').run(owner, appId, encrypted, JSON.stringify(f.info), current.generation, new Date().toISOString(), new Date().toISOString());
  };
  f.seedConnection = async (owner = f.owner) => {
    const id = `connection-${owner}`;
    const encryptedSession = await f.store.encrypt(owner, `session:${id}`, remoteSession);
    const encryptedAccounts = await f.store.encrypt(owner, `accounts:${id}`, [f.account]);
    sql.prepare('INSERT INTO bank_connections (id,owner,app_generation,environment,bank_name,country,encrypted_session,encrypted_accounts,selected_accounts,valid_until,date_from,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id, owner, (await f.store.application(owner)).generation, environment, 'Swedbank', 'SE', encryptedSession, encryptedAccounts, JSON.stringify([accountUid]), future(), bankUtcDate(), 'connected', new Date().toISOString(), new Date().toISOString());
    return id;
  };
  f.start = async (options = {}, servedOrigin = origin) => {
    const response = await f.service.connect(post('connect', { bankName: 'Swedbank', country: 'SE', dateFrom: bankUtcDate(), ...options }, servedOrigin, servedOrigin));
    assert.equal(response.status, 200);
    const cookie = response.headers.get('set-cookie').split(';')[0];
    f.flowCookie = cookie; f.flowState = f.auth.state;
    return response;
  };
  f.callbackRequest = (query = '', cookie = f.flowCookie) => new Request(`${redirect}?state=${f.flowState}&code=one-use-code${query}`, { headers: cookie ? { Cookie: cookie } : {} });
  f.workspace = () => { const row = sql.prepare('SELECT * FROM workspaces WHERE owner=?').get(f.owner); return row ? { ...row, state: JSON.parse(row.payload) } : null; };
  f.connection = () => sql.prepare('SELECT * FROM bank_connections WHERE owner=?').get(f.owner);
  return f;
}


// Independent reviewer inputs/oracles. The shared fixture only composes the
// actual services and synthetic identity/provider; no author test is imported.
const knownPostprocess='Bankhändelserna är sparade. Efterkontrollen behöver köras igen via betalningskontrollen.';
async function reviewFixture(t,{connection=true}={}){
 const f=await fixture(t);await f.seedApp();const id=connection?await f.seedConnection():'absent-synthetic-connection';
 f.sql.prepare('INSERT INTO bank_sync_runs(id,owner,connection_id,imported,skipped,warnings,test,created_at) VALUES(?,?,?,?,?,?,?,?)').run('independent-own-run',f.owner,id,7,3,'[]',0,'2026-11-01T12:00:00.000Z');
 f.warning=raw=>f.sql.prepare('UPDATE bank_sync_runs SET warnings=? WHERE owner=?').run(raw,f.owner);
 f.selection=raw=>f.sql.prepare('UPDATE bank_connections SET selected_accounts=?,auto_sync_enabled=1 WHERE owner=?').run(raw,f.owner);
 f.capture=()=>JSON.stringify(f.sql.prepare("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(({name})=>[name,f.sql.prepare('SELECT * FROM "'+name.replaceAll('"','""')+'" ORDER BY rowid').all()]));
 f.lock=()=>{const before=f.capture();f.sql.exec('PRAGMA query_only=ON');return()=>{assert.equal(f.capture(),before,'status must not mutate any stored table');assert.equal(f.calls.length,0,'status must not dispatch a provider request');};};
 f.read=async()=>{const response=await f.service.status(new Request(origin+'/api/bank/status'));assert.equal(response.status,200);const visible=await response.json();const automatic=await(await f.service.automaticSyncStatus()).json();return{visible,automatic};};
 return f;
}
for(const [label,raw,kept,invalid]of [
 ['broken JSON','{',[],true],['JSON null','null',[],true],['empty object','{}',[],true],['boolean','false',[],true],['number','17',[],true],
 ['mixed with prior warning',JSON.stringify(['Preserve & review',null,{private:'PRIVATE_REVIEW_SENTINEL'},knownPostprocess]),['Preserve & review',knownPostprocess],true],
 ['valid empty','[]',[],false],['valid sequence',JSON.stringify(['', 'First', 'First', knownPostprocess]),['','First','First',knownPostprocess],false],
])test('independent status warning '+label,async t=>{
 const f=await reviewFixture(t);f.warning(raw);const unchanged=f.lock(),{visible,automatic}=await f.read();
 assert.ok(visible.lastRun,'a stored run must not disappear when its warnings are corrupt');assert.equal(visible.lastRun.imported,7);assert.equal(visible.lastRun.skipped,3);
 const warnings=visible.lastRun.warnings;assert.ok(Array.isArray(warnings)&&warnings.every(x=>typeof x==='string'));
 if(invalid){assert.ok(visible.connection.postprocessWarning);assert.match(visible.connection.postprocessWarning,/okänd/i);assert.equal(automatic.postprocessWarning,visible.connection.postprocessWarning);assert.ok(warnings.includes(visible.connection.postprocessWarning));for(const value of kept)assert.ok(warnings.includes(value));}
 else{assert.deepEqual(warnings,kept);assert.equal(visible.connection.postprocessWarning,kept.includes(knownPostprocess)?knownPostprocess:null);assert.equal(automatic.postprocessWarning,visible.connection.postprocessWarning);}
 assert.doesNotMatch(JSON.stringify([visible,automatic]),/PRIVATE_REVIEW_SENTINEL/);unchanged();
});
for(const [label,raw]of [['broken','{'],['null','null'],['object','{}'],['string',JSON.stringify(accountUid)],['partial',JSON.stringify([accountUid,null])],['boolean list','[false]']])test('independent selection format '+label,async t=>{
 const f=await reviewFixture(t);f.selection(raw);const unchanged=f.lock(),{visible,automatic}=await f.read();
 assert.ok(visible.connection.metadataWarning);assert.match(visible.connection.metadataWarning,/okänd/i);assert.equal(automatic.metadataWarning,visible.connection.metadataWarning);
 assert.ok(visible.connection.accounts.every(x=>x.selected===false));assert.equal(automatic.connected,false);assert.equal(automatic.syncAllowed,false);assert.equal(automatic.nextAttemptAt,null);assert.equal(visible.automatic.nextAttemptAt,null);unchanged();
});
test('independent duplicate account list cannot gain access',async t=>{
 const f=await reviewFixture(t);f.selection(JSON.stringify([accountUid,accountUid]));const unchanged=f.lock(),{automatic}=await f.read();assert.equal(automatic.connected,false);assert.equal(automatic.syncAllowed,false);assert.equal(automatic.nextAttemptAt,null);unchanged();
});
test('independent run without a connection retains an explicit unknown warning',async t=>{
 const f=await reviewFixture(t,{connection:false});f.warning('null');const unchanged=f.lock(),{visible,automatic}=await f.read();assert.equal(visible.connection,null);assert.equal(visible.lastRun.imported,7);assert.ok(visible.lastRun.warnings.some(x=>/okänd/i.test(x)));assert.match(automatic.postprocessWarning,/okänd/i);assert.equal(automatic.syncAllowed,false);unchanged();
});
test('independent foreign-owner recent run cannot replace own corrupt warning',async t=>{
 const f=await reviewFixture(t);f.warning('{');
 f.sql.prepare('INSERT INTO bank_sync_runs(id,owner,connection_id,imported,skipped,warnings,test,created_at) VALUES(?,?,?,?,?,?,?,?)').run('foreign-run','foreign-owner','foreign-connection',999,0,'["FOREIGN_REVIEW_SENTINEL"]',0,'2099-01-01T00:00:00.000Z');
 const unchanged=f.lock(),{visible,automatic}=await f.read();assert.equal(visible.lastRun.imported,7);assert.match(visible.connection.postprocessWarning,/okänd/i);assert.doesNotMatch(JSON.stringify([visible,automatic]),/FOREIGN_REVIEW_SENTINEL/);unchanged();
});
test('independent malformed metadata cannot bypass a foreign company selector',async t=>{
 const f=await reviewFixture(t);f.warning('{');f.selection('null');const unchanged=f.lock();
 await assert.rejects(f.service.status(new Request(origin+'/api/bank/status?companyId=workspace:foreign-owner')),error=>error.code==='COMPANY_ACCESS_DENIED');unchanged();
});
test('independent expired consent remains expired when both metadata fields are corrupt',async t=>{
 const f=await reviewFixture(t);f.warning('{}');f.selection('null');f.sql.prepare("UPDATE bank_connections SET valid_until='2000-01-01T00:00:00.000Z' WHERE owner=?").run(f.owner);
 const unchanged=f.lock(),{visible,automatic}=await f.read();assert.equal(visible.connection.connectionStatus,'expired');assert.equal(automatic.connected,false);assert.equal(automatic.syncAllowed,false);assert.equal(automatic.nextAttemptAt,null);assert.ok(visible.connection.metadataWarning);unchanged();
});
test('independent missing company authority remains blocked with corrupt warnings',async t=>{
 const f=await reviewFixture(t);f.warning('null');
 const consent={version:'bank-consent-v1',mode:'company',companyId:'workspace:'+f.owner,actorId:f.owner,membershipVersion:'legacy-owner-v1',requestedScopes:['accounts:read','transactions:read'],grantedScopes:['accounts:read','transactions:read'],validUntil:future(),corporateAuthorization:{status:'unverified',reason:'synthetic missing authority'}};
 f.sql.prepare('UPDATE bank_connections SET consent_metadata=? WHERE owner=?').run(JSON.stringify(consent),f.owner);
 const unchanged=f.lock(),{visible,automatic}=await f.read();assert.equal(visible.connection.connectionStatus,'corporate_authorization_required');assert.equal(automatic.syncAllowed,false);assert.ok(visible.connection.accounts.every(x=>x.importable===false));assert.match(visible.connection.postprocessWarning,/okänd/i);unchanged();
});
test('independent corrupt consent still denies access rather than being rescued by tolerant metadata',async t=>{
 const f=await reviewFixture(t);f.warning('{');f.selection('null');f.sql.prepare("UPDATE bank_connections SET consent_metadata='{' WHERE owner=?").run(f.owner);const unchanged=f.lock();
 await assert.rejects(f.service.status(new Request(origin+'/api/bank/status')),error=>error.code==='COMPANY_ACCESS_DENIED');await assert.rejects(f.service.automaticSyncStatus(),error=>error.code==='COMPANY_ACCESS_DENIED');unchanged();
});
test('independent damaged encrypted account cache is still rejected',async t=>{
 const f=await reviewFixture(t);f.warning('null');f.selection('{}');f.sql.prepare("UPDATE bank_connections SET encrypted_accounts='synthetic invalid ciphertext' WHERE owner=?").run(f.owner);const unchanged=f.lock();await assert.rejects(f.service.status(new Request(origin+'/api/bank/status')));unchanged();
});
